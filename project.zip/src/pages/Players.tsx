import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Players: React.FC = () => {
  const players = [
    { id: 1, name: 'Player One', team: 'Russia', rating: 1.25 },
    { id: 2, name: 'Player Two', team: 'Belarus', rating: 1.20 },
    { id: 3, name: 'Player Three', team: 'France', rating: 1.18 },
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section>
          <h1 className="text-3xl font-bold text-white mb-6">Top Players</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {players.map((player) => (
              <div key={player.id} className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
                <h3 className="text-xl font-semibold text-blue-400 mb-2">{player.name}</h3>
                <p className="text-gray-300">Team: {player.team}</p>
                <p className="text-gray-300">Rating: {player.rating}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Players;