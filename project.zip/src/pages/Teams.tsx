import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import TeamCard from '../components/TeamCard';

const Teams: React.FC = () => {
  const teams = [
    { rank: 1, name: 'Russia National Team', logo: 'https://flagcdn.com/w320/ru.png', points: 950, slug: 'russia' },
    { rank: 2, name: 'Belarus National Team', logo: 'https://flagcdn.com/w320/by.png', points: 920, slug: 'belarus' },
    { rank: 3, name: 'France National Team', logo: 'https://flagcdn.com/w320/fr.png', points: 890, slug: 'france' },
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section>
          <h1 className="text-3xl font-bold text-white mb-6">CS2 Teams Rankings</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {teams.map((team) => (
              <Link key={team.rank} to={`/teams/${team.slug}`} className="block">
                <TeamCard rank={team.rank} name={team.name} logo={team.logo} points={team.points} />
              </Link>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Teams;