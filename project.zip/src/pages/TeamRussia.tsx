import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const TeamRussia: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section className="text-center">
          <img src="https://flagcdn.com/w320/ru.png" alt="Russia National Team Flag" className="w-32 h-20 mx-auto mb-4 rounded" />
          <h1 className="text-3xl font-bold text-white mb-4">Russia National Team</h1>
          <p className="text-gray-300">Details about the Russia National Team coming soon...</p>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default TeamRussia;