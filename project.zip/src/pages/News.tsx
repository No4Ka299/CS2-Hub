import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const News: React.FC = () => {
  const newsItems = [
    { id: 1, title: 'Russia Dominates in Latest Tournament', date: '2023-10-01', summary: 'The Russian national team secured a decisive victory in the recent CS2 championship.' },
    { id: 2, title: 'Belarus Team Shows Strong Performance', date: '2023-09-28', summary: 'Belarus players impressed with their strategic plays in the qualifiers.' },
    { id: 3, title: 'France Announces New Roster', date: '2023-09-25', summary: 'France has updated their team lineup for upcoming matches.' },
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section>
          <h1 className="text-3xl font-bold text-white mb-6">Latest News</h1>
          <div className="space-y-6">
            {newsItems.map((item) => (
              <div key={item.id} className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
                <h2 className="text-xl font-semibold text-blue-400 mb-2">{item.title}</h2>
                <p className="text-gray-400 text-sm mb-2">{item.date}</p>
                <p className="text-gray-300">{item.summary}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default News;