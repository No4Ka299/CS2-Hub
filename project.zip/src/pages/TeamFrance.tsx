import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const TeamFrance: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section className="text-center">
          <img src="https://flagcdn.com/w320/fr.png" alt="France National Team Flag" className="w-32 h-20 mx-auto mb-4 rounded" />
          <h1 className="text-3xl font-bold text-white mb-4">France National Team</h1>
          <p className="text-gray-300">Details about the France National Team coming soon...</p>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default TeamFrance;