import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Tournaments: React.FC = () => {
  const tournaments = [
    { id: 1, name: 'World CS2 Championship', date: '2023-11-01', status: 'Upcoming' },
    { id: 2, name: 'European Qualifiers', date: '2023-10-20', status: 'Ongoing' },
    { id: 3, name: 'National Showdown', date: '2023-09-30', status: 'Completed' },
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section>
          <h1 className="text-3xl font-bold text-white mb-6">Tournaments</h1>
          <div className="space-y-4">
            {tournaments.map((tournament) => (
              <div key={tournament.id} className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
                <h2 className="text-xl font-semibold text-blue-400 mb-2">{tournament.name}</h2>
                <p className="text-gray-300">Date: {tournament.date}</p>
                <p className="text-gray-300">Status: {tournament.status}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Tournaments;