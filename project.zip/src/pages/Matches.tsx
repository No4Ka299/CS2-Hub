import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Matches: React.FC = () => {
  const matches = [
    { id: 1, team1: 'Russia', team2: 'France', date: '2023-10-05', result: 'Russia 2-1 France' },
    { id: 2, team1: 'Belarus', team2: 'Russia', date: '2023-10-10', result: 'Upcoming' },
    { id: 3, team1: 'France', team2: 'Belarus', date: '2023-10-15', result: 'Upcoming' },
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section>
          <h1 className="text-3xl font-bold text-white mb-6">Matches</h1>
          <div className="space-y-4">
            {matches.map((match) => (
              <div key={match.id} className="bg-gray-800 p-4 rounded-lg shadow-lg border border-gray-700 flex justify-between items-center">
                <div className="text-white">
                  <span className="font-semibold">{match.team1}</span> vs <span className="font-semibold">{match.team2}</span>
                </div>
                <div className="text-gray-300 text-sm">
                  {match.date} - {match.result}
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Matches;