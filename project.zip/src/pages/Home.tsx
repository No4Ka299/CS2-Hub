import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Home: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Welcome to Country CS2</h1>
          <p className="text-lg text-gray-300 mb-8">Your ultimate source for CS2 national teams, news, matches, players, and tournaments.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold text-blue-400 mb-2">Teams</h3>
              <p className="text-gray-300">Explore national CS2 teams and their rankings.</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold text-blue-400 mb-2">News</h3>
              <p className="text-gray-300">Stay updated with the latest CS2 news.</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold text-blue-400 mb-2">Matches</h3>
              <p className="text-gray-300">Check out upcoming and past matches.</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold text-blue-400 mb-2">Players</h3>
              <p className="text-gray-300">Discover top players from national teams.</p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Home;