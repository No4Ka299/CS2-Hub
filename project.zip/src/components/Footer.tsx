import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-300 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-white font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-blue-400 transition-colors" aria-label="Twitter">Twitter</a>
              <a href="#" className="hover:text-blue-400 transition-colors" aria-label="Discord">Discord</a>
              <a href="#" className="hover:text-blue-400 transition-colors" aria-label="YouTube">YouTube</a>
            </div>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><Link to="#" className="hover:text-blue-400 transition-colors">Privacy Policy</Link></li>
              <li><Link to="#" className="hover:text-blue-400 transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
          <div>
            <p>&copy; 2025 Country CS2. All rights reserved.</p>
            <p className="mt-2">Built with ❤️ by <a rel="nofollow" target="_blank" href="https://meku.dev" className="text-blue-500 hover:text-blue-400 transition-colors">Meku.dev</a></p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;