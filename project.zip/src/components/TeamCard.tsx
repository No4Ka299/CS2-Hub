import React from 'react';

interface TeamCardProps {
  rank: number;
  name: string;
  logo: string;
  points: number;
}

const TeamCard: React.FC<TeamCardProps> = ({ rank, name, logo, points }) => {
  return (
    <div className="bg-gray-800 p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-700">
      <div className="flex items-center space-x-4">
        <span className="text-blue-400 font-bold text-lg">#{rank}</span>
        <img src={logo} alt={`${name} logo`} className="w-12 h-12 rounded-full" />
        <div>
          <h3 className="text-white font-semibold">{name}</h3>
          <p className="text-gray-300 text-sm">{points} points</p>
        </div>
      </div>
    </div>
  );
};

export default TeamCard;