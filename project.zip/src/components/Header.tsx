import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Search } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-gray-800 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link to="/" className="text-2xl font-bold text-blue-500 hover:text-blue-400 transition-colors">
              Country CS2
            </Link>
          </div>
          <nav className="hidden md:flex space-x-8">
            <Link to="/" className="text-gray-300 hover:text-blue-400 transition-colors">Home</Link>
            <Link to="/teams" className="text-gray-300 hover:text-blue-400 transition-colors">Teams</Link>
            <Link to="/news" className="text-gray-300 hover:text-blue-400 transition-colors">News</Link>
            <Link to="/matches" className="text-gray-300 hover:text-blue-400 transition-colors">Matches</Link>
            <Link to="/players" className="text-gray-300 hover:text-blue-400 transition-colors">Players</Link>
            <Link to="/tournaments" className="text-gray-300 hover:text-blue-400 transition-colors">Tournaments</Link>
          </nav>
          <div className="flex items-center space-x-4">
            <button className="text-gray-300 hover:text-blue-400 transition-colors" aria-label="Search">
              <Search size={20} />
            </button>
            <button
              className="md:hidden text-gray-300 hover:text-blue-400 transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        {isMenuOpen && (
          <div className="md:hidden bg-gray-800 border-t border-gray-600">
            <nav className="flex flex-col space-y-2 py-4">
              <Link to="/" className="text-gray-300 hover:text-blue-400 transition-colors px-4" onClick={() => setIsMenuOpen(false)}>Home</Link>
              <Link to="/teams" className="text-gray-300 hover:text-blue-400 transition-colors px-4" onClick={() => setIsMenuOpen(false)}>Teams</Link>
              <Link to="/news" className="text-gray-300 hover:text-blue-400 transition-colors px-4" onClick={() => setIsMenuOpen(false)}>News</Link>
              <Link to="/matches" className="text-gray-300 hover:text-blue-400 transition-colors px-4" onClick={() => setIsMenuOpen(false)}>Matches</Link>
              <Link to="/players" className="text-gray-300 hover:text-blue-400 transition-colors px-4" onClick={() => setIsMenuOpen(false)}>Players</Link>
              <Link to="/tournaments" className="text-gray-300 hover:text-blue-400 transition-colors px-4" onClick={() => setIsMenuOpen(false)}>Tournaments</Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;